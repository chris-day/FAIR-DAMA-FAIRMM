# FAIR DAMA integrated release candidate

This repository builds ontology 1.0.0 as distribution 1.0.0-rc.1, using the G4-approved graph and inherited mapping exceptions. It produces validated RDF, generated semantic documentation and an owner-review ZIP. It does not publish or deploy.

## Run the pipeline

Use Python 3.11.9, the locked requirements and the configured Java 17.0.21.1 runtime:

```sh
python -m pip install -r requirements-validation.txt
python scripts/pipeline.py
```

The pipeline downloads ROBOT 1.9.11 only if no local JAR is supplied, verifies its SHA-256, rebuilds the closure, runs all tests and reasoning, generates documentation, then creates and verifies the review candidate. To use existing tools:

```sh
python scripts/pipeline.py --robot-jar /path/to/robot-1.9.11.jar --java /path/to/java
```

Build/validation failures stop candidate creation. Dependencies are not silently upgraded. Hosted CI uses .github/workflows/candidate.yml with immutable action commits, read-only repository permissions and no GitHub Release or deployment step. The workflow has been authored and locally checked; an actual hosted run requires an authorised repository and has not been claimed.

## Outputs

- release/FAIR-DAMA-Integrated-1.0.0-rc.1.zip and its SHA-256 file are the deterministic owner-review distribution.
- release/evidence/ retains full execution reports, runtime information and logs separately from the reproducible candidate.
- docs/generated/ contains RDF-derived tools, mapping proposals, historical dispositions, capability progression, query results, source inventory and an import diagram.
- dist/ contains the import entrypoint, asserted Turtle, source-separated TriG, lock/catalogue/JSON-LD manifest and separate inference delta.

Candidate packaging canonicalises generated RDF and normalises owned text; raw pinned inputs remain byte-identical. ZIP entry order, timestamps and permissions are fixed. A separate clean rebuild and second canonical package must match the first archive digest. Byte equivalence assumes the recorded Python/zlib toolchain; semantic graph equivalence is checked independently.

[Migration notes](docs/MIGRATION.md) explain graph scope and compatibility. [Component notices](docs/THIRD_PARTY_NOTICES.md) preserve licence evidence. [Approval records](approvals.json) distinguish approved G1–G4 work from pending G5 sign-off. The new-content licence and public promotion remain owner decisions; no blanket relicensing is applied.
